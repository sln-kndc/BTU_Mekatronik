Overleaf > New Project > Upload Project ile bu ZIP dosyasini yukleyin.
Compiler: pdfLaTeX; Main document: main.tex.
Bu projede yazilim sonuclari yeni basit Python koduna gore guncellenmistir.
